<html>
<head>
   <title>NTI Laravel</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<style>
   .m-r-1em{
       margin-right: 1em;
   }
   .m-b-1em{
       margin-bottom: 1em;
   }
   .m-l-1em{
       margin-left: 1em;
   }

   .mt0{
       margin-top: 0;
   }

</style>
</head>
<body>

<div class="container">
    <div class="page-header">
       <center><h1>Laravel</h1></center> 
    </div>
<table class="table table_hover table-responsive table-bordered">
  <tr>
    <th>id</th>
    <th>name</th>
    <th>email</th>>
    <th>created_at</th>
    <th>Action</th>
    

  </tr>


 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    
    <th><?php echo e($row->id); ?></th>
    <th><?php echo e($row->name); ?></th>
    <th><?php echo e($row->email); ?></th>
    <th><?php echo e($row->created_at); ?></th>
    <th><?php echo e($row->action); ?></th>



  </tr>
  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


 </table>

 </div>

  </body>
 </html>
<?php /**PATH C:\xampp\htdocs\ntilaravel\resources\views/display.blade.php ENDPATH**/ ?>