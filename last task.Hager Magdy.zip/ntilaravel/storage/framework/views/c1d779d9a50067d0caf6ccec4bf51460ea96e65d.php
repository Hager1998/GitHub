<html>
<head>
   <title>NTI Laravel</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<style>
   .m-r-1em{
       margin-right: 1em;
   }
   .m-b-1em{
       margin-bottom: 1em;
   }
   .m-l-1em{
       margin-left: 1em;
   }

   .mt0{
       margin-top: 0;
   }

</style>
</head>
<body>

<div class="container">
    <div class="page-header">
       <center><h1>Laravel</h1></center> 
    </div>
<table class="table table_hover table-responsive table-bordered">
  <tr>
    
    <th>name</th>
    <th>age</th>
    <th>email</th>
    

  </tr>

  <tr>
    
    <td><?php echo e($name); ?></td>
    <td><?php echo e($age); ?></td>
    <td><?php echo e($email); ?></td>
    

  </tr>



 </table>

 </div>

  </body>
 </html>
<?php /**PATH C:\xampp\htdocs\ntilaravel\resources\views/message.blade.php ENDPATH**/ ?>