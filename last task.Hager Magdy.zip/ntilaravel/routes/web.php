<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
   
//});

//Route::get('Message', function () {
  
  //echo 'Hello World';
//});




//Route::get('user/{id?}', function (){
 //echo 'Hello HAGER';
//});

Route::post('postForm', function(){
  echo 'Form data';
   
});



//Route::get('signIn', function () {
 //return view('welcome');
 //});
  




Route::get('ControllerMessage','taskcontroller@printMessage');



Route::get('addUser', function () {
   return view('add');
   });
   

Route::post('blog','taskcontroller@blogData');

Route::get('display', 'taskcontroller@display');





//Route::get('Message', function () {
    //echo'Welcome Back';
//});

//Route::get('addUser', function () {
   // return view('add');
//});



//Route::get('controllerMessage','testcontroller@printName');

//Route::post('store','testcontroller@storeData');


