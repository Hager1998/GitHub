<!DOCTYPE html>
<html lang="en">

<head>
    <title>Register</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container">
        <h2> Register</h2>
        <form action="{{url('/postForm' ) }}" method="post" enctype="multipart/form-data">

         <input type="hidden" name="_token" value="{{csrf_token()}}" />


            <div class="form-group">
                <label for="exampleForControlInput1">title</label>
                <input type="text" name="text" class="form-control" id="exampleForControlInput1" aria-describedby="" placeholder="Enter Name">
            </div>

            <div class="form-group">
                <label for="exampleForControlInput1">content</label>
                <input type="text" name="text" class="form-control" id="exampleForControlInput1"  placeholder="Enter Phone Number">
            </div>

            

          


            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

</body>

</html>









<html>
<head>
   <title>NTI Laravel</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<style>
   .m-r-1em{
       margin-right: 1em;
   }
   .m-b-1em{
       margin-bottom: 1em;
   }
   .m-l-1em{
       margin-left: 1em;
   }

   .mt0{
       margin-top: 0;
   }

</style>
</head>
<body>

<div class="container">
    <div class="page-header">
       <center><h1>Laravel</h1></center> 
    </div>
<table class="table table_hover table-responsive table-bordered">
  <tr>
    
    <th>name</th>
    <th>age</th>
    <th>email</th>
    

  </tr>

  <tr>
    
    <td>{{ $name }}</td>
    <td>{{ $age }}</td>
    <td>{{ $email }}</td>
    

  </tr>



 </table>

 </div>

  </body>
 </html>
