<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use  App\Models\student;

class testcontroller extends Controller{
    //

  public function printName(){
      //echo'HELLO WORLD';
      //return view('message');
      return view('message',["name"=>"Hager" ,"age" => 22 ,"email" => "test@nti.com"]);
  }

  public function storeData(Request $request){


    $data=$this->validate(request(),
   [
     'name'=>'required|min:5|max:10',
     'email'=>'required|email',
     'password'=>'required|min:5',
    ]

    );

    dd($data);
    $op=student::create(['name' => $data['name'], 'email' => $data['email'], 'password' => $data['password'] ]);
   
    $message='';

    if($op){
      echo'inserted';
    }else{
      echo'try again';
    }

    return view('add',['message'=> $message ]);

  }
 
  public function display(){
    $data =student::get();

   return view('display',['data'=>$data]);


  }



 public function deleteStudent($id){
   $op=student :: where('id',$id->delete());
    if($op){
      return back();
    }else{
      echo'try again';
    }
  }

 
  public function showStudent($id){
  
   $data=student:: find($id);
   return view('edit',['studentData'=>$data]);

  }






  



}
