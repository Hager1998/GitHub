<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\student;



class taskcontroller extends Controller
{
    //

 public function printMessage(){


    //echo'Hello World ya GOGO ';
 return view('taskmessage',["name"=> "Hager","age"=> 22,"email"=> "Hager.magdy2020@outlook.com"]);
 // return view('taskmessage')->with('name', 'Hager')->with('age',22)->with('email', 'Hager.magdy2020@outlook.com');
 }




 public function blogData(Request $request){
     $data=$this -> validate(
         request(),
         [
   'name'=> 'required|min:5',
   'email'=> 'required|email',
   'password'=> 'required'
    ]
     );


     $op=student::create(['name'=> $data ['name'], 'email'=>$data ['email'], 'password'=>bcrypt($data ['password'])]);

     $message='';

     if ($op) {
         echo"inserted";
     } else {
         echo"try again";
     }
 }

 public function display(){

  $data= student::get();
  

  return view('display',['data'=>$data]);
 }



 //echo 'Hello World';

  //dd($request->has('title'))  ;
  //echo  $content = $request->content ;
 //echo 'bravo';
}







